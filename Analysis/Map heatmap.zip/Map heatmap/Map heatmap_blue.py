import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
# 1. 准备你的数据（这里用你提供的表格数据）
# 假设你的数据已读取为Pandas DataFrame，命名为df
data = {
    'Country': ['Armenia', 'Australia', 'Austria', 'Azerbaijan', 'Belgium',
                'Brazil', 'Bulgaria', 'Canada', 'Chile', 'China',
                'Colombia', 'Czechia', 'France', 'Germany', 'Greece',
                'India', 'Israel', 'Italy', 'Mexico', 'Netherlands',
                'New Zealand', 'Poland', 'Portugal', 'South Korea', 'Spain',
                'Sweden', 'Turkey', 'USA'],
    'count': [1, 477, 211, 2, 19, 6, 2, 491, 5, 623, 142, 3, 1233, 330, 2, 8, 456, 68, 11, 3, 183, 19, 1, 745, 132, 8, 178, 74]
}
df = pd.DataFrame(data)

# 2. 读取世界地图地理数据
shapefile_path = "ne_110m_admin_0_countries/ne_110m_admin_0_countries.shp"
world = gpd.read_file(shapefile_path)

# 3. 确保台湾地区正确归属中国
if "Taiwan" in world["NAME"].values:
    china_index = world[world["NAME"] == "China"].index
    taiwan_info = world[world["NAME"] == "Taiwan"]

    if not taiwan_info.empty and not china_index.empty:
        world.loc[china_index, "geometry"] = world.loc[china_index, "geometry"].union(taiwan_info.iloc[0]["geometry"])
        world = world[world["NAME"] != "Taiwan"]

# 4. 将你的数据与世界地图数据合并
world = world.merge(df, how="left", left_on="NAME", right_on="Country")

# 5. 处理缺失值
world['count'] = world['count'].fillna(0)

# 6. 准备配色方案
# 定义颜色
unselected_color = '#B4DAEC'  # 浅蓝色
green_low = '#ABD2BE'  # 浅绿色
green_high = '#3E5A49'  # 深绿色

# 创建自定义的绿色渐变色彩映射
green_cmap = LinearSegmentedColormap.from_list('green_gradient', [green_low, green_high])

# 7. 绘制热力图
fig, ax = plt.subplots(1, 1, figsize=(15, 10))

# 首先绘制未选中的国家（count=0）
world_unselected = world[world['count'] == 0]
if not world_unselected.empty:
    world_unselected.plot(color=unselected_color,
                          linewidth=0.8,
                          ax=ax,
                          edgecolor='black',
                          label='Unselected')

# 然后绘制选中的国家（count>0）
world_selected = world[world['count'] > 0]
if not world_selected.empty:
    # 获取选中国家的count值
    counts = world_selected['count']

    # 对选中国家的count值进行归一化，用于颜色映射
    # 因为count=0的国家已经被排除，所以这里不需要考虑0值
    norm = plt.Normalize(vmin=counts.min(), vmax=counts.max())

    # 为每个选中国家计算对应的绿色
    colors = green_cmap(norm(counts))

    # 绘制选中国家
    world_selected.plot(color=colors,
                        linewidth=0.8,
                        ax=ax,
                        edgecolor='black',
                        legend=True,
                        legend_kwds={
                            'label': 'Count value',
                            'orientation': 'vertical',
                            'shrink': 0.6
                        })

# 8. 添加图例说明
# 由于我们手动绘制了未选中的国家，可以添加一个图例项
# 使用代理艺术家来添加未选中国家的图例
from matplotlib.patches import Patch

legend_elements = [
    Patch(facecolor=unselected_color, edgecolor='black', label='Unselected (count=0)')
]
ax.legend(handles=legend_elements, loc='lower left')

# 9. 设置标题和样式
ax.set_title("The distribution of all amplicon samples worldwide", fontsize=16)
ax.set_axis_off()  # 不显示坐标轴

# 10. 显示图像
plt.tight_layout()
plt.show()

# 11. 保存图像
fig.savefig('all_samples_global_heatmap_blue.png', dpi=600, bbox_inches='tight')