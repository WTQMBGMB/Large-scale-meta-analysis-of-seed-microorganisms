import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
# 1. 准备你的数据（这里用你提供的表格数据）
# 假设你的数据已读取为Pandas DataFrame，命名为df
data = {
    'Country': ['Armenia', 'Australia', 'Austria', 'Azerbaijan', 'Belgium',
                'Brazil', 'Bulgaria', 'Canada', 'Chile', 'China',
                'Colombia', 'Czechia', 'France', 'Germany', 'Greece',
                'India', 'Israel', 'Italy', 'Mexico', 'Netherlands',
                'New Zealand', 'Poland', 'Portugal', 'South Korea', 'Spain',
                'Sweden', 'Turkey', 'USA'],
    'count': [1, 477, 211, 2, 19, 6, 2, 491, 5, 623, 142, 3, 1233, 330, 2, 8, 456, 68, 11, 3, 183, 19, 1, 745, 132, 8, 178, 74]
}
df = pd.DataFrame(data)

# 2. 读取世界地图地理数据
# 需要手动下载Natural Earth的110m国家边界数据 (https://www.naturalearthdata.com/downloads/110m-cultural-vectors/)
# 下载后解压，并指定Shapefile文件的路径
shapefile_path = "ne_110m_admin_0_countries/ne_110m_admin_0_countries.shp"  # 请替换为实际路径
world = gpd.read_file(shapefile_path)

# 3. 确保台湾地区正确归属中国[1](@ref)
# 检查数据集中是否存在台湾
if "Taiwan" in world["NAME"].values:
    # 找到中国的索引和台湾的信息
    china_index = world[world["NAME"] == "China"].index
    taiwan_info = world[world["NAME"] == "Taiwan"]

    if not taiwan_info.empty and not china_index.empty:
        # 将台湾的几何数据合并到中国
        world.loc[china_index, "geometry"] = world.loc[china_index, "geometry"].union(taiwan_info.iloc[0]["geometry"])
        # 删除原来的台湾数据
        world = world[world["NAME"] != "Taiwan"]

# 4. 将你的数据与世界地图数据合并
# 注意：确保国家名称匹配，可能需要根据实际数据调整
world = world.merge(df, how="left", left_on="NAME", right_on="Country")

# 5. 处理缺失值（对于没有数据的国家，可以填充为0或NaN）
world['count'] = world['count'].fillna(0)  # 或将填充为0改为填充为NaN：world['count'] = world['count'].fillna(np.nan)

# 6. 绘制热力图
fig, ax = plt.subplots(1, 1, figsize=(15, 10))

# 绘制热力图，数值越大颜色越深
world.plot(column='count',
           cmap='Reds',  # 使用红色系，颜色越深表示值越大
           linewidth=0.8,
           ax=ax,
           edgecolor='black',
           legend=True,
           missing_kwds={"color": "lightgray"}  # 缺失数据的国家颜色
           )

# 设置标题和样式
ax.set_title("The distribution of all amplicon samples worldwide", fontsize=16)
ax.set_axis_off()  # 不显示坐标轴

# 7. 显示图像
plt.tight_layout()
plt.show()

# 8. 保存图像（可选）
fig.savefig('all_samples_global_heatmap_red.png', dpi=600, bbox_inches='tight')